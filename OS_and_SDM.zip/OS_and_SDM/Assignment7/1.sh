#!/bin/bash

echo "Login Name : $LOGNAME"
echo "Home Directory : $HOME"
